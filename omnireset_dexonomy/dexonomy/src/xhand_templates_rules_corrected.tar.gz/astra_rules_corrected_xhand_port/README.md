# XHand templates with restored Shadow requirements

This repair replaces the disk-corrected package. The earlier package changed contact membership in 15 types. Its static checks did not establish preservation of the authors' mapped contact requirements.

All 31 repaired templates preserve the mapped Shadow contact-link sets and required groups. Types 19 and 21 remain excluded. Source YAML files and reference XHand geometry are unchanged.

The user requires both contact fidelity and the grasp appearance discussed throughout the session. The repaired render was inspected against the human insets. This document does not claim the user has accepted the repaired image yet.



The validator reads the authors' Shadow YAML files directly. It maps finger proximal segments to XHand L1 and finger middle and distal segments to XHand L2. Thumb middle maps to thumb L1 and thumb distal maps to thumb L2. Shadow palm and little-finger metacarpal map to XHand palm. Duplicate mapped groups collapse only when they are identical.

Every final annotation writes its required groups explicitly. Conversion is checked to preserve those groups. For 33, index L2, thumb L2 and thumb L1 remain three separately required groups. The converted templates retain this distinction.

Positions and normals are fitted on XHand surfaces. This is a retargeted surface annotation, not a copy of Shadow contact coordinates or point counts. Every mapped link remains represented. The objects are agent-selected primitive posing proxies. They are not author-provided per-type objects. The authors supplied the human reference insets.

The same source audit finds 15 differing templates in the earlier package and zero in the repaired package. The independent conversion validator also checks the converted contact bodies and required groups.

## Restored contacts

| Type | Restored links | Removed addition |
| --- | --- | --- |
| 4 Adducted Thumb | index_rota_link1, mid_link1, pinky_link1, ring_link1 | None |
| 5 Light Tool | index_rota_link1, mid_link1, pinky_link1, ring_link1 | None |
| 10 Power Disk | thumb_rota_link1 | None |
| 11 Power Sphere | thumb_rota_link1 | palm |
| 12 Precision Disk | palm, thumb_rota_link1 | None |
| 15 Fixed Hook | thumb_rota_link1 | None |
| 17 Index Finger Extension | index_rota_link1, mid_link1, palm, pinky_link1, ring_link1 | None |
| 18 Extension Type | palm, thumb_rota_link1 | None |
| 20 Writing Tripod | palm | None |
| 22 Parallel Extension | palm, thumb_rota_link1 | None |
| 26 Sphere 4 Finger | index_rota_link1, mid_link1, pinky_link1, ring_link1, thumb_rota_link1 | None |
| 28 Sphere 3 Finger | index_rota_link1, mid_link1, ring_link1, thumb_rota_link1 | None |
| 30 Palmar | index_rota_link1, mid_link1, palm, pinky_link1, ring_link1, thumb_rota_link1 | None |
| 32 Ventral | mid_link2, palm, pinky_link2, ring_link2 | None |
| 33 Inferior Pincer | thumb_rota_link1 | None |

## Geometry and appearance

**4.** Restored the four L1 contacts. The thumb remains aligned with the cylinder.

**5.** Restored the four L1 contacts. The thumb pad presses the tool.

**10.** Restored thumb L1. Retained the broad-face thumb and four-finger disk arrangement with space for the little finger.

**11.** Restored thumb L1 and removed the added palm requirement. The fingers wrap the sphere.

**12.** Restored thumb L1 and palm contact. Retained the thin disk and thumb contact on its rim.

**15.** Restored the required thumb L1 contact. The distal thumb remains extended beside the shaft.

**17.** Restored all four L1 contacts and the palm. The index remains extended along the object.

**18.** Restored thumb L1 and palm contact. Fingers support the thin disk with slight bend.

**20.** Restored palm contact while retaining the tripod arrangement around the cylinder.

**22.** Restored thumb L1 and palm contact. Retained the square plate and extended fingers with slight bend.

**26.** Restored all four L1 contacts and thumb L1. The pads wrap the sphere.

**28.** Restored index, middle and ring L1 and thumb L1. Retained the larger sphere and three-finger arrangement.

**30.** Restored all four L1 contacts, thumb L1 and palm contact. Repositioned the thin disk to contact the palm and slightly bent fingers.

**32.** Restored middle, ring, little-finger and palm contacts. The index remains extended along a shorter shaft.

**33.** Restored thumb L1 as a separately required group. Thumb and index remain extended and approximately parallel around the sphere.

All 31 annotations convert through upstream Dexonomy and pass independent static checks. The maximum contact gap is 1.798 mm. The maximum normal error is 28.987 degrees. The maximum exact object penetration is 0.597 mm. The maximum vertex penetration is 1.695 mm. No checked self penetration remains.

The contact links and required groups are source-derived constraints. The geometric tolerances and visual fitting constraints are agent-authored checks. These are separate checks. Neither substitutes for the other.

Dynamic holding and downstream object yield were not tested in this repair. No new Isaac hold-test or force-closure success rate is claimed.
